import React,{useEffect,useState} from "react";
import {createRoot} from "react-dom/client";
import "./style.css";

const API="http://localhost:8080/api/orders";

function App(){
 const [form,setForm]=useState({product:"Cake",quantity:1,customization:"",deliveryDate:"",address:"",contactName:"",phone:""});
 const [orders,setOrders]=useState([]); const [message,setMessage]=useState("");
 const load=()=>fetch(API).then(r=>r.json()).then(setOrders);
 useEffect(load,[]);
 const change=e=>setForm({...form,[e.target.name]:e.target.value});
 const submit=e=>{e.preventDefault();setMessage("Saving...");
   fetch(API,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({...form,quantity:Number(form.quantity)})})
   .then(async r=>{if(!r.ok) throw new Error("Validation failed"); return r.json()})
   .then(o=>{setMessage(`Order #${o.id} confirmed. Total: ₹${o.total}`);load();})
   .catch(()=>setMessage("Please check all required fields and backend connection."));
 };
 const updateStatus=(id,status)=>fetch(`${API}/${id}/status`,{method:"PUT",headers:{"Content-Type":"application/json"},body:JSON.stringify({status})}).then(load);
 return <div className="page"><header><h1>🍰 Home Bakery</h1><p>Order fresh homemade treats</p></header>
 <main><section className="card"><h2>Place Your Order</h2><form onSubmit={submit}>
 {["contactName","phone","address","deliveryDate","customization"].map(n=>
   n==="customization"?<textarea key={n} name={n} placeholder="Customization (eggless, message, flavor...)" value={form[n]} onChange={change}/>:
   <input key={n} name={n} type={n==="deliveryDate"?"date":"text"} placeholder={n} value={form[n]} onChange={change} required={n!=="customization"}/>)}
 <select name="product" value={form.product} onChange={change}><option>Cake</option><option>Cupcake</option><option>Cookies</option></select>
 <input name="quantity" type="number" min="1" value={form.quantity} onChange={change}/>
 <button>Place Order</button></form><p className="message">{message}</p></section>
 <section className="card"><h2>Baker Order Management</h2>{orders.length===0?<p>No orders yet.</p>:orders.map(o=><div className="order" key={o.id}>
 <b>Order #{o.id} - {o.product}</b><span>Qty: {o.quantity} | Total: ₹{o.total}</span><span>Customization: {o.customization||"None"}</span><span>Delivery: {o.deliveryDate}</span><strong>Status: {o.status}</strong>
 <select value={o.status} onChange={e=>updateStatus(o.id,e.target.value)}><option>PLACED</option><option>PREPARING</option><option>READY</option><option>OUT_FOR_DELIVERY</option><option>DELIVERED</option></select>
 </div>)}</section></main></div>
}
createRoot(document.getElementById("root")).render(<App/>);
