package com.bakery.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDate;

@Entity
@Table(name="orders")
public class Order {
    @Id @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;

    @NotBlank private String product;
    @Min(1) private int quantity;
    private String customization;
    @NotNull private LocalDate deliveryDate;
    @NotBlank private String address;
    @NotBlank private String contactName;
    @NotBlank private String phone;
    private double total;
    private String status = "PLACED";

    public Long getId(){ return id; }
    public String getProduct(){ return product; }
    public void setProduct(String v){product=v;}
    public int getQuantity(){return quantity;}
    public void setQuantity(int v){quantity=v;}
    public String getCustomization(){return customization;}
    public void setCustomization(String v){customization=v;}
    public LocalDate getDeliveryDate(){return deliveryDate;}
    public void setDeliveryDate(LocalDate v){deliveryDate=v;}
    public String getAddress(){return address;}
    public void setAddress(String v){address=v;}
    public String getContactName(){return contactName;}
    public void setContactName(String v){contactName=v;}
    public String getPhone(){return phone;}
    public void setPhone(String v){phone=v;}
    public double getTotal(){return total;}
    public void setTotal(double v){total=v;}
    public String getStatus(){return status;}
    public void setStatus(String v){status=v;}
}
