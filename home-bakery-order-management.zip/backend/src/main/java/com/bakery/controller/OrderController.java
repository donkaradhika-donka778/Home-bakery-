package com.bakery.controller;

import com.bakery.model.Order;
import com.bakery.service.OrderService;
import jakarta.validation.Valid;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/orders")
@CrossOrigin(origins="http://localhost:5173")
public class OrderController {
    private final OrderService service;
    public OrderController(OrderService service){this.service=service;}

    @PostMapping
    public ResponseEntity<Order> create(@Valid @RequestBody Order o){
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(o));
    }
    @GetMapping
    public List<Order> all(){return service.all();}
    @GetMapping("/{id}")
    public Order one(@PathVariable Long id){return service.one(id);}
    @PutMapping("/{id}/status")
    public Order status(@PathVariable Long id,@RequestBody Map<String,String> body){
        return service.status(id, body.getOrDefault("status","PLACED"));
    }
}
