package com.bakery.service;

import com.bakery.model.Order;
import com.bakery.repository.OrderRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class OrderService {
    private final OrderRepository repo;
    public OrderService(OrderRepository repo){this.repo=repo;}

    public Order create(Order o){
        double unitPrice = switch(o.getProduct().toLowerCase()){
            case "cake" -> 500;
            case "cupcake" -> 80;
            case "cookies" -> 150;
            default -> 300;
        };
        o.setTotal(unitPrice * o.getQuantity());
        o.setStatus("PLACED");
        return repo.save(o);
    }
    public List<Order> all(){ return repo.findAll(); }
    public Order one(Long id){ return repo.findById(id).orElseThrow(); }
    public Order status(Long id, String status){
        Order o=one(id); o.setStatus(status.toUpperCase()); return repo.save(o);
    }
}
