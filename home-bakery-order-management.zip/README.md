# Home Bakery Order Management System

Stack:
- Java 17+
- Spring Boot
- REST API
- Spring Data JPA / Hibernate
- MySQL
- React

## Run
1. Create MySQL database: `CREATE DATABASE bakery_db;`
2. Update backend/src/main/resources/application.properties with your MySQL username/password.
3. Run backend with Maven: `mvn spring-boot:run`
4. In frontend: `npm install` then `npm run dev`

Backend API:
- POST `/api/orders` - create order
- GET `/api/orders` - list orders
- PUT `/api/orders/{id}/status` - update delivery/order status
- GET `/api/orders/{id}` - get one order

The UI includes order form, confirmation, total, customization summary, delivery status, and baker-side order management.
